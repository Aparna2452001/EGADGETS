from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.

class CustUser(AbstractUser):
    phone=models.IntegerField(null=True)
    address=models.CharField(max_length=500)
    pro_pic=models.ImageField(upload_to="user_images",null=True)
    options=(
        ("Customer","Customer"),
        ("Store","Store"),
    )
    usertype=models.CharField(max_length=100,choices=options,default="Customer")


class ProductModel(models.Model):
    name=models.CharField(max_length=100)
    model=models.CharField(max_length=100)
    image=models.ImageField(upload_to='product_images',null=True)
    price=models.IntegerField()
    desc=models.CharField(max_length=400)

    