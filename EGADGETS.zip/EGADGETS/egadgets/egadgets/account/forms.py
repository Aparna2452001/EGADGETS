from django import forms
from .models import CustUser,ProductModel
from django.contrib.auth.forms import UserCreationForm


class RegForm(UserCreationForm):
    class Meta:
        model=CustUser
        fields=["first_name","last_name","email","phone","username","usertype","address","pro_pic","password1","password2"]


class LogForm(forms.Form):
    username=forms.CharField(label="Enter Username ",max_length=200,widget=forms.TextInput(attrs={"class":"form-control"}))
    password=forms.CharField(label="Enter password",max_length=200,widget=forms.PasswordInput(attrs={"class":"form-control"}))

class PoForm(forms.ModelForm):
    class Meta:
        model=ProductModel
        fields="__all__"
    
