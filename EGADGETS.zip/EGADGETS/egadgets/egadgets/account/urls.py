from django.urls import path
from.views import *

urlpatterns=[
    path('reg/',RegView.as_view(),name="re"),
    path('log/',LogView.as_view(),name="log"),
    path('shome/',Shome.as_view(),name="sh"),
    path('addpro/',AddProduct.as_view(),name="prod"),
    # path('str/',Store.as_view(),name="strv"),
    path('edpr/<int:bid>',EditProdct.as_view(),name="edpr"),
    path('dlt/<int:bid>',Dltprod.as_view(),name="dltp"),
    path('lout/',LogOut.as_view(),name="lout"),




    # path('strhome/',LogView.as_view(),name="log")
 

]