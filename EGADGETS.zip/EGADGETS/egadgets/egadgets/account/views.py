from django.shortcuts import render,redirect
from django.views.generic import TemplateView,CreateView,FormView,View
from django.contrib import messages
from .models import CustUser,ProductModel
from django.urls import reverse_lazy
from .forms import RegForm,LogForm,PoForm
from django.contrib.auth import authenticate,login,logout
# Create your views here.

class MhomeView(TemplateView):
    template_name="mhome.html"
   

class RegView(CreateView):
    template_name="reg.html"
    form_class=RegForm
    model=CustUser
    success_url=reverse_lazy("log")


class LogView(FormView):
    template_name="login.html"
    form_class=LogForm
    def post(self,request,*args,**kwargs):
        uname=request.POST.get("username")
        psw=request.POST.get("password")
        user=authenticate(request,username=uname,password=psw)
        if user:
            if user.usertype=="Store":
                login(request,user)
                messages.success(request,"user login successfully")
                return redirect("sh")
            else:
                login(request,user)
                return redirect("uh")
        else:
            messages.error(request,"login failed")
            return redirect('log')
        
class Shome(View):
    def get(self,request):
        prdct=ProductModel.objects.all()
        return render(request,"storehome.html",{'data':prdct})


class AddProduct(CreateView):
    template_name="addpro.html"
    form_class=PoForm
    model=ProductModel
    success_url=reverse_lazy("sh")


class EditProdct(View):
    def get(self,request,*args,**kwargs):
        bid=kwargs.get("bid")
        p=ProductModel.objects.get(id=bid)
        f=PoForm(instance=p)
        return render(request,"editpro.html",{"form":f})
    def post(self,request,*args,**kwargs):
        bid=kwargs.get("bid")
        p=ProductModel.objects.get(id=bid)
        form_data=PoForm(data=request.POST,files=request.FILES,instance=p)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"Product Updated")
            return redirect("sh")
        else:
            return redirect(request,"editpro.html",{"form":form_data})
        

class Dltprod(View):
    def get(self,request,*args,**kwargs):
        bid=kwargs.get("bid")
        item=ProductModel.objects.get(id=bid)
        item.delete()
        return redirect('sh')

class LogOut(View):
    def get(self,request):
        logout(request)
        return redirect("log")
    





