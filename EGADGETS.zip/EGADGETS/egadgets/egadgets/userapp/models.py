from django.db import models
# from account.models import CustUser,ProductModel

from django.core.exceptions import ValidationError
from django.contrib.auth.models import AbstractUser


# Create your models here.

# class Review(models.Model):
#     comment=models.CharField(max_length=500,null=True)
#     date=models.DateField(auto_now_add=True,null=True)
#     user=models.ForeignKey(CustUser,on_delete=models.CASCADE,related_name='review',null=True)
#     product=models.ForeignKey(ProductModel,on_delete=models.CASCADE,related_name='product',null=True)

# class Cart(models.Model):
#     user=models.ForeignKey(CustUser,on_delete=models.CASCADE)
#     product=models.ForeignKey(ProductModel,on_delete=models.CASCADE)
#     quantity=models.IntegerField()
#     status=models.CharField(max_length=30,default="cart")

# from django.db import models

class Cust_user(AbstractUser):
    phone=models.IntegerField()
    address=models.CharField(max_length=100)
    profile_pic=models.ImageField(upload_to="user_profile_pic",null=True)
    options=(
        ('Customer','Customer'),
        ('Staff','Staff')
    )
    user_type=models.CharField(max_length=10,choices=options,default='Customer')
class Company(models.Model):
    com_name=models.CharField(max_length=50)
    img=models.ImageField(upload_to='com_logo_image')
class Product(models.Model):
    product_name=models.CharField(max_length=50,)
    p_image=models.ImageField(upload_to="product_images",verbose_name='product_image')
    price=models.IntegerField()
    stock=models.IntegerField()
    ram=models.IntegerField(null=True)
    rom=models.IntegerField(null=True)
    processor=models.CharField(max_length=50,null=True)
    camera=models.IntegerField(null=True)
    front_cam=models.IntegerField(null=True)
    battery=models.IntegerField(null=True)
    pro_company=models.ForeignKey(Company,on_delete=models.CASCADE,related_name="company",null=True)


class Cart(models.Model):
    product_name=models.ForeignKey(Product,on_delete=models.CASCADE,related_name='cart_product')
    user=models.ForeignKey(Cust_user,on_delete=models.CASCADE,related_name='cart_user')
    date=models.DateField(auto_now_add=True)

class Review(models.Model):
    review=models.CharField(max_length=100)
    date=models.DateField(auto_now_add=True)
    rating=models.FloatField()
    user=models.ForeignKey(Cust_user,on_delete=models.CASCADE,related_name='revie_user')
    product=models.ForeignKey(Product,on_delete=models.CASCADE,related_name='revie_product')
    
    # def clean(self):
    #     if self.rating < 1 or self.rating > 5:
    #         raise ValidationError("Rating must be between 1 and 5.")