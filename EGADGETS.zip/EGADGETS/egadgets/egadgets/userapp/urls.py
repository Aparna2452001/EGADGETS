from django.urls import path
from.views import *

urlpatterns=[
    path('cst/',Userhom.as_view(),name="uh"),
    # path('buy/<int:bid>',BuyView.as_view(),name="buy"),
    # path('next/',PaymentView.as_view(),name="nxt"),
    # path('ordr/',PlaceOrder.as_view(),name="ordr"),
    # # path('addcrt/<int:pid>',CartView.as_view(),name="cart"),
    # path('ord/',PaymentView.as_view(),name="or"),
    # path('addreview/<int:id>',Addreview.as_view(),name="review"),
    # path('addcart/<int:id>',Viewcart.as_view(),name="ac"),
    # path('vcart/',AddCart.as_view(),name="cv"),


    path('view_product/<int:id>',Product_view.as_view(),name="cview_product"),
    # path('add_review/<int:id>',Add_review.as_view(),name="cadd_review"),
    path('product_details/<int:id>',Product_details.as_view(),name="product_details"),
    path('addcart/<int:id>',Add_cart.as_view(),name="addcart"),
    path('viewcart/',View_cart.as_view(),name="viewcart"),
    # path('deletecart/<int:id>',Delete_icart.as_view(),name="deletecart"),

]

    





    

