
# from django import forms
# from .models import Cart,Review
from django import forms
from account.forms import *
from account.models import *
from .models import Review

class Reviewform(forms.ModelForm):
    class Meta:
        model=Review
        exclude=["user","product"]
        widgets={
            'review':forms.Textarea()
        }


# class BuyForm(forms.Form):
#     name=forms.CharField(label="Enter name",max_length=100,widget=forms.TextInput(attrs={"class":"form-control"}))
#     phone=forms.IntegerField(label="phone",widget=forms.NumberInput(attrs={"class":"form-control"}))
#     address=forms.CharField(label="Enter address",max_length=500,widget=forms.TextInput(attrs={"class":"form-control"}))
#     email=forms.EmailField(label="Enter email",max_length=300,widget=forms.EmailInput(attrs={"class":"form-control"}))
#     city=forms.CharField(label="Enter city",max_length=100,widget=forms.TextInput(attrs={"class":"form-control"}))
#     location=forms.CharField(label="Enter location",max_length=100,widget=forms.TextInput(attrs={"class":"form-control"}))
#     pincode=forms.IntegerField(label="Enter pin-code",widget=forms.NumberInput(attrs={"class":"form-control"}))


# class ReviewForm(forms.ModelForm):
#     class Meta:
#         model=Review
#         exclude=["user","product"]
#         wigdets={
#             'review':forms.Textarea
#         }
        
        
# class CartForm(forms.ModelForm):
#     class Meta:
#         model=Cart
#         fields=['quantity']
#         widgets={
#             "quantity":forms.TextInput(attrs={"class":"form_control"})
#         }