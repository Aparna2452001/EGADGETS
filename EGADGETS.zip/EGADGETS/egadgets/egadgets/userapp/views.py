from django.shortcuts import render,redirect
from django.views.generic import View,CreateView,TemplateView,FormView
from account.models import *
from .forms import *

from account.models import ProductModel
from.forms import ReviewForm,BuyForm,CartForm

from django.contrib import messages
from .models import Review,Cart
from django.contrib.auth import authenticate 
from django.urls import reverse_lazy







# class Uhome(View):
#     def get(self,request):
#         prdct=ProductModel.objects.all()
#         return render(request,"userhome.html",{'data':prdct})
class Userhom(View):
    def get(self,request):
        prdct=ProductModel.objects.all()
        return render(request,"userhome.html",{'data':prdct})

# Create your views here.                        
# class Buy(FormView):
    # template_name="buy.html"
    # form_class=

# class BuyView(View):
#     def get(self,request,*args,**kwargs):
#          bid=kwargs.get("bid")
#          p=ProductModel.objects.get(id=bid)
#          return render(request,"buy.html",{"form":p})
    
    

# class ReviewView(CreateView):
#     template_name="userhome.html"
#     form_class=ReviewForm
#     success_url=reverse_lazy("uh")

   


# class ReviewView(CreateView):
#     template_name="userhome.html"
#     form_class=ReviewForm
    #   success_url=reverse_lazy("rev")



# class PlaceOrder(CreateView):
#     def get(self,request,*args,**kwargs):
#         f=BuyForm()
#         return render(request,"order.html",{'form':f})
#     def purchase(request):
#         messages.success(request,"Order Placed")
#         return redirect("uh")
    
    
# class PaymentView(TemplateView):
#     template_name="next.html"
    


# class CartView(View):

    
#     def get(self,request,*args,**kwargs):
#         id=kwargs.get("pid")
#         item=ProductModel.objects.get(id=id)
#         form=CartForm()
#         return render(request,"addcart.html",{"data":item,"form":form})
#     def post(self,request,*args,**kwargs):
#         id=kwargs.get("pid")
#         item=ProductModel.objects.get(id=id)
#         user=request.user
#         q=request.POST.get("quantity")
#         Cart.objects.create(user=user,product=item,quantity=q)
#         return redirect("uh")


# class Addreview(CreateView):
#     form_class=ReviewForm
#     model=Review
#     template_name="addreview.html"
#     success_url=reverse_lazy("uh")
#     def form_valid(self, form):
#         form.instance.product=ProductModel.objects.get(id=self.kwargs.get('id'))
#         form.instance.user=self.request.user
#         return super().form_valid(form)




# class Delete_icart(View):
#     def get(self,request,*args,**kwargs):
#         id=kwargs.get('id')
#         cart=Cart.objects.get(id=id)
#         cart.delete()
#         return redirect("viewcart")
    

# class View_cart(TemplateView):
#     template_name="view_cart.html"
    
#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context["data"] =Cart.objects.filter(user=self.request.user)
#         context["review"] =Review.objects.all()
#         return context

# class Viewcart(TemplateView):
#     template_name="vcart.html"
#     def get_context_data(self, **kwargs):
#         context=super().get_context_data(**kwargs)
#         context["data"]=Cart.objects.filter(user=self.request.user)
#         context["review"]=Review.objects.all()
#         return context
    
# class CartView(View):
#     def get(self,request,*args,**kwargs):
#         id=kwargs.get("pid")
#         item=ProductModel.objects.get(id=id)
#         form=CartForm()


# class AddCart(View):
#     def get(self,request,args,*kwargs):
#         id=kwargs.get("pid")
#         item=ProductModel.objects.get(id=id)
#         form=CartForm()
#         return render(request,"addcart.html",{"data":item,"form":form})
#     def post(self,request,args,*kwargs):
#         id=kwargs.get("pid")
#         item=ProductModel.objects.get(id=id)
#         user=request.user
#         q=request.POST.get("quantity")
#         Cart.objects.create(user=user,product=item,quantity=q)
#         return redirect("uh")


class Product_view(TemplateView):
    template_name="cviewproduct.html"
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["data"] =ProductModel.objects.filter(pro_company_id=self.kwargs.get('id')) 
        return context

class Product_details(FormView):
    template_name="product_detail.html"
    form_class=Reviewform
    def get_context_data(self,**kwargs):
        context = super().get_context_data(**kwargs)
        context["data"] =ProductModel.objects.get(id=self.kwargs.get('id'))
        context["review"] =Review.objects.all()
        return context


class Add_cart(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get('id')
        data=ProductModel.objects.get(id=id)
        Cart.objects.create(product_name=data,user=request.user)
        return redirect("viewcart")

class View_cart(TemplateView):
    template_name="view_cart.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["data"] =Cart.objects.filter(user=self.request.user)
        context["review"] =Review.objects.all()
        return context